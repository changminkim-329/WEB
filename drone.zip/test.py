from tensorflow import keras as tk
from tensorflow.keras.models import model_from_json
import tensorflow as tf
import detector_setting as set
import cv2
import matplotlib.pyplot as plt
from utils import WeightReader, decode_netout, draw_boxes
import numpy as np
json_file = open("./model/yolov2_model.json", "r")
loaded_model_json = json_file.read()
print(loaded_model_json)
json_file.close()
print("load json")
loaded_model = model_from_json(loaded_model_json)

loaded_model.load_weights("./model/yolov2_weight.h5")
frame = cv2.imread("./auto_drive.jpeg")
frame = cv2.cvtColor(frame,cv2.COLOR_BGR2RGB)

prec_image = cv2.resize(frame, (416, 416)).astype('float32')

prec_image = prec_image / 255.0


image_predict = loaded_model.predict(np.expand_dims(prec_image, axis=0))


boxes = decode_netout(image_predict[0],
                      obj_threshold=set.OBJ_THRESHOLD,
                      nms_threshold=set.NMS_THRESHOLD,
                      anchors=set.ANCHORS,
                      nb_class=set.CLASS)

box_image = draw_boxes(frame, boxes, labels=set.LABELS)

frame = box_image.astype('int32')

print(frame)

plt.imshow(frame)
plt.show()