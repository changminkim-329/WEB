from django.apps import AppConfig


class IotConfig(AppConfig):
    name = 'iot'
